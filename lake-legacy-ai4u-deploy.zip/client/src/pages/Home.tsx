import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { 
  BookOpen, 
  Users, 
  MessageSquare, 
  CheckCircle2, 
  Star, 
  TrendingUp, 
  Download, 
  Copy,
  Target,
  ArrowRight,
  Phone,
  Mail,
  Building2,
  Award,
  Sparkles,
  Shield,
  Crown,
  Briefcase
} from "lucide-react";
import { toast } from "sonner";

// Wealth Personas Data
const PERSONAS = [
  {
    title: "The Tech Founder",
    icon: Briefcase,
    traits: ["Speed-focused", "Data-driven", "Privacy-conscious"],
    approach: "Lead with efficiency and discretion. Show property analytics, ROI potential, and off-market opportunities.",
    greeting: "I understand you value your time. Let me show you exactly what you need to know."
  },
  {
    title: "The Family Legacy Builder",
    icon: Crown,
    traits: ["Multi-generational thinking", "Quality-focused", "Relationship-oriented"],
    approach: "Emphasize property heritage, neighborhood stability, and long-term value appreciation.",
    greeting: "This property has the kind of timeless quality that families treasure for generations."
  },
  {
    title: "The Privacy-First Executive",
    icon: Shield,
    traits: ["Discretion paramount", "Security-conscious", "Low-profile preferred"],
    approach: "Highlight confidentiality protocols, gated access, and exclusive showing arrangements.",
    greeting: "Your privacy is my priority. Everything we discuss stays completely confidential."
  },
  {
    title: "The Luxury Lifestyle Buyer",
    icon: Sparkles,
    traits: ["Experience-driven", "Design-focused", "Amenity-conscious"],
    approach: "Showcase unique features, architectural details, and lifestyle enhancement opportunities.",
    greeting: "Let me walk you through the exceptional details that make this property truly special."
  }
];

// Email Templates
const EMAIL_TEMPLATES = [
  {
    title: "Initial Outreach",
    subject: "Exclusive Lake Property Opportunity",
    body: `Dear [Name],

I hope this message finds you well. I'm reaching out regarding an exceptional lakefront property that matches your expressed interests.

This property offers:
• [Key Feature 1]
• [Key Feature 2]
• [Key Feature 3]

Given the discrete nature of this opportunity, I'd be pleased to arrange a private showing at your convenience.

Would [Date/Time] work for a brief conversation?

Warm regards,
Jamie McNeely
Coldwell Banker - Leonhardt Team`
  },
  {
    title: "Post-Showing Follow-Up",
    subject: "Thank You - [Property Address]",
    body: `Dear [Name],

Thank you for taking the time to view [Property Address] today. It was a pleasure showing you this exceptional property.

I wanted to follow up on the points we discussed:
• [Discussion Point 1]
• [Discussion Point 2]

Please don't hesitate to reach out with any questions. I'm here to support your decision-making process.

Best regards,
Jamie McNeely
651-788-5684`
  },
  {
    title: "Off-Market Opportunity",
    subject: "Private Listing - Exclusive Preview",
    body: `Dear [Name],

I wanted to reach out personally about a unique opportunity that hasn't hit the market yet.

This property offers exactly what we discussed:
• [Specific Requirement 1]
• [Specific Requirement 2]
• [Specific Requirement 3]

Due to the seller's preference for privacy, I'm only sharing this with a select group of qualified buyers.

Are you available for a private viewing this week?

Confidentially yours,
Jamie McNeely`
  }
];

// Objection Handling
const OBJECTIONS = [
  {
    objection: "The price seems high",
    response: "I understand your concern. Let me share the comparable sales data and unique features that justify this valuation. This property offers [specific features] that similar properties in the area don't have.",
    principle: "Validate, then educate with data"
  },
  {
    objection: "I want to think about it",
    response: "Absolutely, this is an important decision. What specific aspects would you like more information about? I'm here to help you gather everything you need.",
    principle: "Uncover the real concern"
  },
  {
    objection: "Can we negotiate on price?",
    response: "I appreciate your interest in finding the right value. Let me discuss your offer with the seller and understand their flexibility. What price point would make this work for you?",
    principle: "Be the bridge, not the barrier"
  },
  {
    objection: "I need to talk to my spouse/partner",
    response: "Of course, that's completely understandable. Would it be helpful to schedule a time when you're both available? I'm happy to answer any questions together.",
    principle: "Facilitate the decision process"
  }
];

// 7-Star Showing Protocol
const SHOWING_PROTOCOL = [
  { step: "Pre-Arrival", items: ["Confirm appointment 24 hours prior", "Research client background and preferences", "Prepare property highlight sheet", "Ensure property is pristine"] },
  { step: "Arrival", items: ["Greet warmly but professionally", "Offer refreshment", "Set expectations for the tour", "Ask about specific interests"] },
  { step: "Tour", items: ["Lead with best features", "Allow silence for absorption", "Point out unique details", "Share relevant neighborhood insights"] },
  { step: "Discussion", items: ["Ask open-ended questions", "Listen more than you speak", "Address concerns directly", "Provide comparative market data"] },
  { step: "Follow-Up", items: ["Send thank you within 2 hours", "Provide requested information", "Schedule next steps", "Maintain regular contact"] }
];

// Quiz Data
const QUIZ = [
  {
    q: "When showing a luxury property, what should you prioritize?",
    a: ["Talking about all features quickly", "Allowing silence for the client to absorb", "Focusing only on price"],
    correct: 1,
    explain: "High-net-worth clients appreciate space to think. Silence shows confidence and respect."
  },
  {
    q: "How should you handle a price objection?",
    a: ["Immediately offer to reduce price", "Validate concern and provide data", "Ignore and change subject"],
    correct: 1,
    explain: "Validation + education builds trust. Always have comparable data ready."
  },
  {
    q: "What's the best approach for privacy-conscious clients?",
    a: ["Share their interest with other agents", "Maintain strict confidentiality", "Post about them on social media"],
    correct: 1,
    explain: "Privacy is paramount. Discretion builds long-term relationships with high-net-worth clients."
  },
  {
    q: "When should you follow up after a showing?",
    a: ["Within 2 hours", "Next week", "Only if they contact you"],
    correct: 0,
    explain: "Prompt follow-up (within 2 hours) shows professionalism and keeps momentum."
  }
];

export default function Home() {
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizScore, setQuizScore] = useState<number | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  const runQuiz = () => {
    let score = 0;
    QUIZ.forEach((q, i) => {
      if (quizAnswers[i] === q.correct) score++;
    });
    setQuizScore(score);
  };

  const resetQuiz = () => {
    setQuizAnswers([]);
    setQuizScore(null);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary via-primary/90 to-primary/80 text-primary-foreground py-20 md:py-32">
        <div className="container">
          <div className="max-w-4xl">
            <Badge className="mb-4 bg-accent text-accent-foreground">Lake & Legacy Estates</Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Your Luxury Real Estate Confidence Hub
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-primary-foreground/90 leading-relaxed">
              Master the art of serving high-net-worth clients with confidence, precision, and grace. 
              Your complete educational platform for luxury real estate success.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" variant="secondary" className="text-lg">
                <BookOpen className="mr-2" size={20} />
                Start Learning
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent text-primary-foreground border-primary-foreground/30 hover:bg-primary-foreground/10">
                <Target className="mr-2" size={20} />
                Take Quiz
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-card border-b">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent mb-2">4</div>
              <div className="text-sm text-muted-foreground">Wealth Personas</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent mb-2">12+</div>
              <div className="text-sm text-muted-foreground">Ready Templates</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent mb-2">7</div>
              <div className="text-sm text-muted-foreground">Star Protocol</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent mb-2">100%</div>
              <div className="text-sm text-muted-foreground">Confidence</div>
            </div>
          </div>
        </div>
      </section>

      {/* Wealth Personas Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Understanding Wealth Personas</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Learn to recognize and adapt to different high-net-worth client types for more effective communication.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {PERSONAS.map((persona, idx) => {
              const Icon = persona.icon;
              return (
                <Card key={idx} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-2xl mb-2">{persona.title}</CardTitle>
                        <CardDescription className="text-base">{persona.greeting}</CardDescription>
                      </div>
                      <Icon className="text-accent" size={32} />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <div className="font-semibold mb-2 text-sm text-muted-foreground">Key Traits:</div>
                      <div className="flex flex-wrap gap-2">
                        {persona.traits.map((trait, i) => (
                          <Badge key={i} variant="secondary">{trait}</Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="font-semibold mb-2 text-sm text-muted-foreground">Approach:</div>
                      <p className="text-sm leading-relaxed">{persona.approach}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Communication Templates Section */}
      <section className="py-16 md:py-24 bg-secondary/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Communication Templates</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Professional, proven email templates ready to customize for your luxury clients.
            </p>
          </div>

          <Tabs defaultValue="0" className="max-w-4xl mx-auto">
            <TabsList className="grid w-full grid-cols-3">
              {EMAIL_TEMPLATES.map((template, idx) => (
                <TabsTrigger key={idx} value={idx.toString()}>
                  {template.title}
                </TabsTrigger>
              ))}
            </TabsList>
            {EMAIL_TEMPLATES.map((template, idx) => (
              <TabsContent key={idx} value={idx.toString()}>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare size={20} />
                      {template.title}
                    </CardTitle>
                    <CardDescription>Subject: {template.subject}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <pre className="whitespace-pre-wrap font-sans text-sm bg-muted p-4 rounded-lg leading-relaxed">
                      {template.body}
                    </pre>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      variant="outline" 
                      onClick={() => copyToClipboard(template.body, template.title)}
                    >
                      <Copy className="mr-2" size={16} />
                      Copy Template
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Objection Handling Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Objection Handling Mastery</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Turn objections into opportunities with proven response frameworks.
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-4">
            {OBJECTIONS.map((item, idx) => (
              <Card key={idx} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg flex items-start gap-2">
                    <span className="text-destructive">"</span>
                    {item.objection}
                    <span className="text-destructive">"</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <div className="text-sm font-semibold text-accent mb-1">Your Response:</div>
                    <p className="text-sm leading-relaxed bg-accent/5 p-3 rounded-lg border border-accent/20">
                      {item.response}
                    </p>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-muted-foreground mb-1">Principle:</div>
                    <p className="text-xs italic text-muted-foreground">{item.principle}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 7-Star Showing Protocol */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-accent/10 to-accent/5">
        <div className="container">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Star className="text-accent" fill="currentColor" size={24} />
              <Star className="text-accent" fill="currentColor" size={24} />
              <Star className="text-accent" fill="currentColor" size={24} />
            </div>
            <h2 className="text-3xl md:text-5xl font-bold mb-4">7-Star Showing Protocol</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Your step-by-step checklist for delivering exceptional property showings.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-5 gap-4">
              {SHOWING_PROTOCOL.map((phase, idx) => (
                <Card key={idx} className="bg-card">
                  <CardHeader>
                    <div className="w-10 h-10 rounded-full bg-accent text-accent-foreground flex items-center justify-center font-bold mb-2">
                      {idx + 1}
                    </div>
                    <CardTitle className="text-lg">{phase.step}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {phase.items.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <CheckCircle2 className="text-accent mt-0.5 flex-shrink-0" size={16} />
                          <span className="leading-snug">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Quiz Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">Test Your Knowledge</h2>
              <p className="text-lg text-muted-foreground">
                Quick confidence check - see how well you've mastered the material.
              </p>
            </div>

            <div className="space-y-6">
              {QUIZ.map((q, qIdx) => (
                <Card key={qIdx}>
                  <CardHeader>
                    <CardTitle className="text-lg">Q{qIdx + 1}. {q.q}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {q.a.map((answer, aIdx) => (
                        <label
                          key={aIdx}
                          className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                            quizAnswers[qIdx] === aIdx
                              ? "border-accent bg-accent/10"
                              : "border-border hover:bg-muted/50"
                          }`}
                        >
                          <input
                            type="radio"
                            name={`q${qIdx}`}
                            checked={quizAnswers[qIdx] === aIdx}
                            onChange={() => {
                              const newAnswers = [...quizAnswers];
                              newAnswers[qIdx] = aIdx;
                              setQuizAnswers(newAnswers);
                            }}
                            className="w-4 h-4"
                          />
                          <span>{answer}</span>
                        </label>
                      ))}
                    </div>
                    {quizScore !== null && (
                      <div className={`mt-4 p-3 rounded-lg text-sm ${
                        quizAnswers[qIdx] === q.correct
                          ? "bg-green-50 text-green-900 border border-green-200"
                          : "bg-red-50 text-red-900 border border-red-200"
                      }`}>
                        {q.explain}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              <div className="flex items-center justify-between gap-4 pt-4">
                {quizScore === null ? (
                  <Button size="lg" onClick={runQuiz} className="w-full md:w-auto">
                    <Target className="mr-2" size={20} />
                    Score My Quiz
                  </Button>
                ) : (
                  <>
                    <div className="text-lg font-semibold">
                      Score: <span className="text-accent text-2xl">{quizScore}/{QUIZ.length}</span>
                      <span className="ml-3 text-muted-foreground text-base">
                        {quizScore === 4 ? "Excellent! 🎉" : quizScore >= 3 ? "Great work!" : "Review and retry"}
                      </span>
                    </div>
                    <Button variant="outline" onClick={resetQuiz}>
                      <ArrowRight className="mr-2" size={16} />
                      Reset Quiz
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Downloads Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Quick Reference Downloads</h2>
            <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
              Copy these resources to your notes, email, or favorite tools.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <Card className="bg-primary-foreground text-primary">
              <CardHeader>
                <Download className="mb-2 text-accent" size={28} />
                <CardTitle>Personal Playbook</CardTitle>
                <CardDescription>One-page reference guide</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                Quick reference for mindset, protocols, and key frameworks.
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  onClick={() => copyToClipboard(
                    "# Lake & Legacy Personal Playbook\n\n- Mindset: Privacy, Precision, Calm\n- 7-Star Showings checklist\n- Email templates ready\n- Client personas mastered\n- Objection handling frameworks",
                    "Playbook"
                  )}
                >
                  <Copy className="mr-2" size={16} />
                  Copy
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-primary-foreground text-primary">
              <CardHeader>
                <CheckCircle2 className="mb-2 text-accent" size={28} />
                <CardTitle>Day-of Checklist</CardTitle>
                <CardDescription>Pre-showing workflow</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                Essential steps for every luxury property showing.
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline"
                  onClick={() => copyToClipboard(
                    "- [ ] Confirm appointment 24hrs prior\n- [ ] Research client background\n- [ ] Prepare property highlights\n- [ ] Ensure pristine condition\n- [ ] Set greeting strategy",
                    "Checklist"
                  )}
                >
                  <Copy className="mr-2" size={16} />
                  Copy
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-primary-foreground text-primary">
              <CardHeader>
                <Award className="mb-2 text-accent" size={28} />
                <CardTitle>LinkedIn Bio</CardTitle>
                <CardDescription>Professional positioning</CardDescription>
              </CardHeader>
              <CardContent className="text-sm">
                Polished bio snippet for your professional profiles.
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline"
                  onClick={() => copyToClipboard(
                    "Quiet, high-trust real estate for discerning clients. Off-market sourcing • 7-Star showings • Privacy-first negotiation • Lake & Legacy Digital Concierge",
                    "Bio"
                  )}
                >
                  <Copy className="mr-2" size={16} />
                  Copy
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact/About Jamie Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="mb-4">Your Luxury Real Estate Partner</Badge>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Jamie McNeely</h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Winter Homebuying Specialist serving Minnesota's luxury real estate market. 
                  I specialize in helping buyers navigate high-end properties with confidence, 
                  discretion, and exceptional service.
                </p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3">
                    <Phone className="text-accent" size={20} />
                    <a href="tel:651-788-5684" className="hover:text-accent transition-colors">651-788-5684</a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="text-accent" size={20} />
                    <a href="mailto:jamie.mcneely@cbrealty.com" className="hover:text-accent transition-colors">
                      jamie.mcneely@cbrealty.com
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Building2 className="text-accent" size={20} />
                    <span className="text-sm">Coldwell Banker - Leonhardt Team</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Building2 className="text-muted-foreground" size={20} />
                    <span>Forest Lake Office, 56 East Broadway Ave, Ste. 104</span>
                  </div>
                </div>
                <Button size="lg" className="w-full md:w-auto">
                  <Mail className="mr-2" size={20} />
                  Get In Touch
                </Button>
              </div>
              <div className="bg-gradient-to-br from-accent/20 to-accent/5 rounded-2xl p-8 md:p-12">
                <div className="space-y-6">
                  <div>
                    <div className="text-4xl font-bold text-accent mb-2">7-Star</div>
                    <div className="text-sm text-muted-foreground">Service Standard</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-accent mb-2">100%</div>
                    <div className="text-sm text-muted-foreground">Client Satisfaction</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-accent mb-2">Privacy</div>
                    <div className="text-sm text-muted-foreground">First Approach</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8 border-t border-primary-foreground/10">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <div className="font-bold text-lg mb-1">Lake & Legacy Estates</div>
              <div className="text-sm text-primary-foreground/70">
                Luxury Real Estate Confidence Hub
              </div>
            </div>
            <div className="text-sm text-primary-foreground/70 text-center md:text-right">
              © AI4U, LLC. AI4Utech.com, Lee Hanna-Owner.
              <br />
              <span className="text-xs">Powered by innovation and excellence.</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
